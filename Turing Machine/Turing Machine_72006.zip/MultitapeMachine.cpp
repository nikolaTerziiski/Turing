#include "MultitapeMachine.h"


void MultitapeMachine::transform()
{
	//for each node in the vector we do the transition
	//lets say we have to transform every node in the vector in it depends on if the node data % 2 == 0. If its true wrties 1
	//If it's not writes 0.

}
