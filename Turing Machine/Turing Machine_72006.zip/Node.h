#pragma once

struct Node {
	char data;
	Node* prev;
	Node* next;
};